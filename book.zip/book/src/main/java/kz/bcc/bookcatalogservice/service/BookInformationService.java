package kz.bcc.bookcatalogservice.service;

import kz.bcc.bookcatalogservice.model.Book;

public interface BookInformationService {

    Book getBookInformationById(Long id);
}
