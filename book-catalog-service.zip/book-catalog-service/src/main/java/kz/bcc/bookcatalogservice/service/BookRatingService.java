package kz.bcc.bookcatalogservice.service;

public interface BookRatingService {

    Double getBookRatingById(Long id);
}
